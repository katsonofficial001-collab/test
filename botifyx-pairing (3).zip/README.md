# BotifyX pairing server

Serves the BotifyX website and links WhatsApp by **QR code** or **pairing code**, then gives you a session ID (`BOTIFY-X-base64...`).

## Railway (simplest if the panel won't install)
1. Put the project files at the root of a **private GitHub repo** (`server.js` and `package.json` at the top level; `.gitignore` already skips `node_modules` and `.env`).
2. Railway: New Project, Deploy from GitHub repo, pick it. Node 22 is pinned (`engines` and `.node-version`) so npm can fetch Baileys' GitHub dependency.
3. Settings, Networking, **Generate Domain**. Open that https address.
4. Optional variables: `GITHUB_URL`, `RELEASES_URL`, `SUPPORT_URL`. Do not set `PORT`; Railway provides it.

## Why a normal panel install fails
Baileys depends on one package (`libsignal`) that is fetched straight from GitHub, not from npm. Panels with npm 12 (or no git) refuse that (`EALLOWGIT`). There is no safe npm-registry copy to swap in, so install the dependencies on a machine that allows it and upload them.

## Steps (Termux, PC or any VPS with internet)
1. Termux only, once: `pkg install -y git nodejs-lts zip`
2. Unzip this project, open the folder, run: `bash bundle.sh`
3. It writes `botifyx-ready.zip` (project + `node_modules`) next to the folder.
4. Upload `botifyx-ready.zip` to the panel, unzip it in the server's root folder.
5. Start the server. If the panel's own "Installing Packages" step prints an error, ignore it: the server still starts from the uploaded `node_modules`. If it does not, set the startup command to `node server.js`.
6. Open `http://YOUR-NODE-IP:YOUR-PORT`. The "Preview mode" banner disappears when the server is detected.

## Notes
- Pairing needs the panel to reach WhatsApp's servers (outbound), even if it blocks npm.
- Optional env variables (see `.env.example`): `GITHUB_URL`, `RELEASES_URL`, `SUPPORT_URL`. Empty is fine: those buttons just dim.
- A pairing lasts 45 seconds. After linking, WhatsApp restarts the connection once; the server handles it, builds the session ID from `creds.json`, and also sends it to your own chat.
- Numbers stay in memory only and nothing is logged. Limits: 15 pairings at once, 3 at once per visitor, 8 starts per 10 minutes per visitor.

Not tested against live WhatsApp yet. Tell me what you see.
