'use strict';
/**
 * BotifyX pairing server
 * Serves the website (./public) and a small API that links a WhatsApp number
 * by QR or pairing code, then returns a session ID: "BOTIFY-X-base64" + base64(creds.json)
 *
 *   POST   /api/pair        { mode: "qr" | "code", number?: "2348012345678" } -> { id }
 *   GET    /api/pair/:id    -> { state, qr?, code?, session?, number?, error? }
 *   DELETE /api/pair/:id    cancel
 *   GET    /api/status      anonymous counters
 *   GET    /api/health      { ok: true }
 *   GET    /api/config      links from env (GITHUB_URL, RELEASES_URL, SUPPORT_URL)
 *
 * Privacy: numbers live in memory only; nothing is written to logs. Creds sit in a
 * temp folder only while linking and are deleted the moment the session ID is built.
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const pino = require('pino');
const QRCode = require('qrcode');
const baileys = require('@whiskeysockets/baileys');

const makeWASocket = baileys.default || baileys.makeWASocket;
const { useMultiFileAuthState, Browsers, DisconnectReason, fetchLatestBaileysVersion, jidNormalizedUser } = baileys;

const PORT = Number(process.env.PORT || process.env.SERVER_PORT || 3000);
const PREFIX = 'BOTIFY-X-base64';
const TTL_MS = 45 * 1000;          // pairing window
const KEEP_MS = 10 * 60 * 1000;    // how long a finished session ID can be fetched
const MAX_ACTIVE = 15;             // concurrent pairings on this instance
const MAX_PER_IP = 3;              // concurrent pairings per visitor
const MAX_STARTS_PER_10MIN = 8;    // per visitor

const logger = pino({ level: 'silent' });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const sessions = new Map();
const stats = { started: 0, linked: 0, expired: 0 };
const recent = [];
const hits = new Map();

function record(s, status) {
  recent.unshift({
    mode: s.mode === 'qr' ? 'QR' : 'Code',
    status,
    seconds: Math.round((Date.now() - s.created) / 1000),
    at: new Date().toISOString().slice(11, 19) + ' UTC',
  });
  if (recent.length > 8) recent.length = 8;
}

function closeSock(s) {
  const sock = s.sock;
  s.sock = null;
  try { if (sock) sock.end(undefined); } catch (_) {}
  fs.rm(s.dir, { recursive: true, force: true }, () => {});
}

function fail(s, msg, expired) {
  if (s.state === 'connected') return;
  s.done = true;
  s.state = 'failed';
  s.error = msg;
  if (expired) stats.expired++;
  record(s, expired ? 'expired' : 'failed');
  closeSock(s);
}

async function finish(s, sock) {
  if (s.done) return;
  s.done = true;
  try {
    await sleep(1500); // let creds.json flush to disk
    const raw = fs.readFileSync(path.join(s.dir, 'creds.json'));
    const me = jidNormalizedUser(sock.user.id);
    s.session = PREFIX + Buffer.from(raw).toString('base64');
    s.number = me.split('@')[0];
    s.state = 'connected';
    stats.linked++;
    record(s, 'linked');
    // Also drop the session ID into the user's own chat (Message yourself)
    try { await sock.sendMessage(me, { text: s.session }); await sleep(2500); } catch (_) {}
  } catch (e) {
    s.done = false;
    fail(s, 'Could not read the session. Please try again.');
    return;
  }
  closeSock(s);
}

async function boot(s) {
  const { state, saveCreds } = await useMultiFileAuthState(s.dir);
  let version;
  try { version = (await fetchLatestBaileysVersion()).version; } catch (_) {}
  const sock = makeWASocket({
    version,
    auth: state,
    logger,
    browser: Browsers.ubuntu('Chrome'),
    printQRInTerminal: false,
    syncFullHistory: false,
    markOnlineOnConnect: false,
    generateHighQualityLinkPreview: false,
  });
  s.sock = sock;
  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('connection.update', async (u) => {
    if (s.done || s.sock !== sock) return;
    const { connection, lastDisconnect, qr } = u;

    if (qr) {
      if (s.mode === 'qr') {
        try { s.qr = await QRCode.toDataURL(qr, { margin: 1, width: 320 }); s.state = 'qr'; } catch (_) {}
      } else if (!s.codeAsked) {
        s.codeAsked = true;
        try {
          const c = await sock.requestPairingCode(s.phone);
          s.code = (c.match(/.{1,4}/g) || [c]).join('-');
          s.state = 'code';
        } catch (_) {
          fail(s, 'Could not request a pairing code. Check the number and try again.');
        }
      }
    }

    if (connection === 'open') await finish(s, sock);

    if (connection === 'close') {
      const status = lastDisconnect && lastDisconnect.error && lastDisconnect.error.output
        ? lastDisconnect.error.output.statusCode : undefined;
      if (status === DisconnectReason.restartRequired) {
        // Normal step right after a successful link: reopen with the saved creds
        s.state = 'linking';
        const old = sock;
        s.sock = null;
        try { old.end(undefined); } catch (_) {}
        boot(s).catch(() => fail(s, 'Linking failed. Please try again.'));
      } else {
        fail(s, status === DisconnectReason.loggedOut
          ? 'WhatsApp rejected the link. Please try again.'
          : 'Connection closed before linking finished. Please try again.');
      }
    }
  });
}

// Expire pairings and clean up
setInterval(() => {
  const now = Date.now();
  for (const [id, s] of sessions) {
    const age = now - s.created;
    if (!s.done && age > TTL_MS) fail(s, 'Session expired. Generate a new code to try again.', true);
    if (age > KEEP_MS) { closeSock(s); sessions.delete(id); }
  }
  for (const [ip, arr] of hits) {
    const fresh = arr.filter((t) => now - t < 10 * 60 * 1000);
    if (fresh.length) hits.set(ip, fresh); else hits.delete(ip);
  }
}, 5000).unref();

const app = express();
app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use(express.json({ limit: '1kb' }));

if (process.env.ALLOW_ORIGIN) {
  app.use((req, res, next) => {
    res.set('Access-Control-Allow-Origin', process.env.ALLOW_ORIGIN);
    res.set('Access-Control-Allow-Headers', 'Content-Type');
    res.set('Access-Control-Allow-Methods', 'GET,POST,DELETE,OPTIONS');
    if (req.method === 'OPTIONS') return res.sendStatus(204);
    next();
  });
}
app.use('/api', (req, res, next) => { res.set('Cache-Control', 'no-store'); next(); });

app.get('/api/health', (req, res) => res.json({ ok: true }));
app.get('/api/config', (req, res) => res.json({
  github: process.env.GITHUB_URL || '',
  releases: process.env.RELEASES_URL || '',
  support: process.env.SUPPORT_URL || '',
}));
app.get('/api/status', (req, res) => {
  let active = 0;
  for (const s of sessions.values()) if (!s.done) active++;
  res.json({ ...stats, active, recent });
});

app.post('/api/pair', (req, res) => {
  const mode = req.body && req.body.mode;
  if (mode !== 'qr' && mode !== 'code') return res.status(400).json({ error: 'Choose QR code or pairing code.' });
  let phone;
  if (mode === 'code') {
    phone = String((req.body && req.body.number) || '').replace(/\D/g, '');
    if (phone.length < 8 || phone.length > 15) return res.status(400).json({ error: 'Enter your full number with country code, digits only.' });
  }
  const ip = req.ip;
  let active = 0, mine = 0;
  for (const s of sessions.values()) if (!s.done) { active++; if (s.ip === ip) mine++; }
  const arr = hits.get(ip) || [];
  if (active >= MAX_ACTIVE) return res.status(429).json({ error: 'The server is busy. Try again in a moment.' });
  if (mine >= MAX_PER_IP || arr.length >= MAX_STARTS_PER_10MIN) return res.status(429).json({ error: 'Too many attempts. Wait a few minutes and try again.' });
  arr.push(Date.now()); hits.set(ip, arr);

  const s = {
    id: crypto.randomBytes(12).toString('hex'), ip, mode, phone,
    dir: fs.mkdtempSync(path.join(os.tmpdir(), 'bx-')),
    state: 'starting', done: false, created: Date.now(),
  };
  sessions.set(s.id, s);
  stats.started++;
  boot(s).catch(() => fail(s, 'Could not start a session. Please try again.'));
  res.json({ id: s.id });
});

app.get('/api/pair/:id', (req, res) => {
  const s = sessions.get(req.params.id);
  if (!s) return res.status(404).json({ error: 'Session not found or expired.' });
  const out = { state: s.state };
  if (s.state === 'qr') out.qr = s.qr;
  if (s.code) out.code = s.code;
  if (s.state === 'connected') { out.session = s.session; out.number = s.number; }
  if (s.state === 'failed') out.error = s.error;
  res.json(out);
});

app.delete('/api/pair/:id', (req, res) => {
  const s = sessions.get(req.params.id);
  if (s && !s.done) { s.done = true; s.state = 'failed'; s.error = 'Cancelled.'; closeSock(s); }
  res.json({ ok: true });
});

app.use(express.static(path.join(__dirname, 'public')));

process.on('unhandledRejection', () => {});
process.on('uncaughtException', (e) => console.error('uncaught:', e && e.message));

app.listen(PORT, '0.0.0.0', () => console.log('BotifyX pairing server running on port ' + PORT));
