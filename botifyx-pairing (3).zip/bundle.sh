#!/usr/bin/env bash
# Run this on a machine WITH internet and git (Termux, PC, VPS), NOT on the panel.
# It installs every dependency (including the one Baileys fetches from GitHub),
# then packs the project + node_modules into one zip you upload to the panel.
#
# Termux first-time setup:  pkg install -y git nodejs-lts zip
set -e
cd "$(dirname "$0")"
command -v git >/dev/null || { echo "git is missing. Termux: pkg install git"; exit 1; }
command -v zip >/dev/null || { echo "zip is missing. Termux: pkg install zip"; exit 1; }
# npm 12 refuses git dependencies, so run npm 11 for the install.
npx -y npm@11 install --omit=dev --no-audit --no-fund
test -d node_modules/express || { echo "Install failed: node_modules/express is missing"; exit 1; }
rm -f ../botifyx-ready.zip
zip -qr ../botifyx-ready.zip . -x ".git/*" -x "*.zip"
echo "Done: $(cd .. && pwd)/botifyx-ready.zip  (upload it to the panel and unzip)"
